import 'package:flutter/material.dart';

Color dark_blue = Color(0xFF018197);

TextStyle buttonStyleblue = TextStyle(color: Colors.blue, fontFamily: "Helvetica");
TextStyle productTitleStyle = TextStyle(fontSize: 20, fontFamily: "Helvetica", fontWeight: FontWeight.bold);
TextStyle whiteItallictTitleStyle = TextStyle(fontSize: 20, fontFamily: "Helvetica", fontStyle: FontStyle.italic, color: Colors.white);