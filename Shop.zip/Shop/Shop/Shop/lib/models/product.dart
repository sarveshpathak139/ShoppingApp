import 'package:flutter/material.dart';

class Product {
  String name;
  double price;
  AssetImage image;
  Product(this.image, this.name, this.price);
}