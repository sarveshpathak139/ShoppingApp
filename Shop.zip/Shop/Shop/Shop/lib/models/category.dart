

import 'package:flutter/material.dart';

class Category {
  List<AssetImage> images;
  String title;
  List<String> categories;
  Category(this.images, this.title, this.categories);
}